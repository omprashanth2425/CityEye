from datetime import datetime, timezone
from sqlalchemy import String, Float, Integer, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column
from geoalchemy2 import Geometry
from app.database.db import Base

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True)
    role: Mapped[str] = mapped_column(String(50))
    organization: Mapped[str | None] = mapped_column(String(160), nullable=True)

class Bus(Base):
    __tablename__ = "buses"
    id: Mapped[int] = mapped_column(primary_key=True)
    vehicle_number: Mapped[str] = mapped_column(String(40), unique=True)
    fleet_id: Mapped[str] = mapped_column(String(60))
    camera_configuration: Mapped[str] = mapped_column(String(40), default="front,rear")
    gps_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(30), default="active")
    last_latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    last_longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

class Detection(Base):
    __tablename__ = "detections"
    id: Mapped[int] = mapped_column(primary_key=True)
    bus_id: Mapped[int] = mapped_column(ForeignKey("buses.id"))
    detection_type: Mapped[str] = mapped_column(String(60))
    confidence: Mapped[float] = mapped_column(Float)
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    detected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    evidence_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    frame_reference: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="pending")

class Event(Base):
    __tablename__ = "events"
    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    event_type: Mapped[str] = mapped_column(String(60), index=True)
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    first_detected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    last_detected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    detection_count: Mapped[int] = mapped_column(Integer, default=1)
    severity: Mapped[str] = mapped_column(String(20), default="Moderate")
    status: Mapped[str] = mapped_column(String(30), default="open")
    evidence_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    geom = mapped_column(Geometry("POINT", srid=4326), nullable=True)

class EventDetection(Base):
    __tablename__ = "event_detections"
    id: Mapped[int] = mapped_column(primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id"))
    detection_id: Mapped[int] = mapped_column(ForeignKey("detections.id"))
    bus_id: Mapped[int] = mapped_column(ForeignKey("buses.id"))
    detected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

class Incident(Base):
    __tablename__ = "incidents"
    id: Mapped[int] = mapped_column(primary_key=True)
    incident_id: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    event_id: Mapped[int | None] = mapped_column(ForeignKey("events.id"), nullable=True)
    incident_type: Mapped[str] = mapped_column(String(60))
    verification_status: Mapped[str] = mapped_column(String(30), default="pending")
    vehicle_detected: Mapped[bool] = mapped_column(Boolean, default=False)
    plate_number: Mapped[str | None] = mapped_column(String(30), nullable=True)
    plate_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    detected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    evidence_url: Mapped[str | None] = mapped_column(Text, nullable=True)

class Route(Base):
    __tablename__ = "routes"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    origin: Mapped[str] = mapped_column(String(160))
    destination: Mapped[str] = mapped_column(String(160))
    distance_km: Mapped[float] = mapped_column(Float)
    geometry = mapped_column(Geometry("LINESTRING", srid=4326), nullable=True)

class RouteScore(Base):
    __tablename__ = "route_scores"
    id: Mapped[int] = mapped_column(primary_key=True)
    route_id: Mapped[int] = mapped_column(ForeignKey("routes.id"))
    traffic_score: Mapped[float] = mapped_column(Float)
    road_condition_score: Mapped[float] = mapped_column(Float)
    waterlogging_score: Mapped[float] = mapped_column(Float)
    hazard_score: Mapped[float] = mapped_column(Float)
    distance_score: Mapped[float] = mapped_column(Float)
    consequence_score: Mapped[float] = mapped_column(Float)
    severity: Mapped[str] = mapped_column(String(20))
