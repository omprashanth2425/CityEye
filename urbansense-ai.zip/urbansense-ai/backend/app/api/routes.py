from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.database.db import get_db
from app.models.entities import Detection, Event, Incident, Bus, Route, RouteScore
from app.schemas.api import *
from app.services.event_engine import upsert_event
from app.services.routing import score_route

router = APIRouter(prefix="/api")

@router.get("/health")
def health(): return {"status":"ok","product":"UrbanSense AI"}

@router.post("/detections", response_model=DetectionOut)
def create_detection(payload: DetectionCreate, db: Session = Depends(get_db)):
    if not db.get(Bus, payload.bus_id): raise HTTPException(404, "Bus not found")
    d=Detection(**payload.model_dump()); db.add(d); db.flush()
    if d.confidence >= .5:
        upsert_event(db,d); d.status="verified" if d.confidence >= .75 else "candidate"
    else: d.status="benign"
    db.commit(); db.refresh(d); return d

@router.get("/detections", response_model=list[DetectionOut])
def list_detections(db: Session=Depends(get_db)): return db.scalars(select(Detection).order_by(Detection.detected_at.desc())).all()

@router.get("/events", response_model=list[EventOut])
def list_events(db: Session=Depends(get_db)): return db.scalars(select(Event).order_by(Event.last_detected_at.desc())).all()

@router.get("/events/{event_id}", response_model=EventOut)
def event_detail(event_id: str, db: Session=Depends(get_db)):
    e=db.scalar(select(Event).where(Event.event_id==event_id))
    if not e: raise HTTPException(404,"Event not found")
    return e

@router.patch("/events/{event_id}")
def update_event(event_id: str, status: str, severity: str|None=None, db: Session=Depends(get_db)):
    e=db.scalar(select(Event).where(Event.event_id==event_id))
    if not e: raise HTTPException(404,"Event not found")
    e.status=status
    if severity: e.severity=severity
    db.commit(); return {"message":"updated","event_id":event_id}

@router.post("/incidents", response_model=IncidentOut)
def create_incident(payload: IncidentCreate, db: Session=Depends(get_db)):
    i=Incident(incident_id=f"INC-{uuid4().hex[:8].upper()}", **payload.model_dump())
    i.verification_status="verified" if payload.vehicle_detected and (payload.plate_confidence or 0)>=.75 else "pending"
    db.add(i); db.commit(); db.refresh(i); return i

@router.get("/incidents", response_model=list[IncidentOut])
def list_incidents(db: Session=Depends(get_db)): return db.scalars(select(Incident).order_by(Incident.detected_at.desc())).all()

@router.patch("/incidents/{incident_id}/verification")
def verify_incident(incident_id: str, status: str, db: Session=Depends(get_db)):
    i=db.scalar(select(Incident).where(Incident.incident_id==incident_id))
    if not i: raise HTTPException(404,"Incident not found")
    i.verification_status=status; db.commit(); return {"incident_id":incident_id,"verification_status":status}

@router.get("/map/events")
def map_events(db: Session=Depends(get_db)):
    return [{"event_id":e.event_id,"type":e.event_type,"lat":e.latitude,"lng":e.longitude,"severity":e.severity,"status":e.status,"count":e.detection_count} for e in db.scalars(select(Event)).all()]

@router.get("/map/traffic")
def traffic(db: Session=Depends(get_db)):
    return [{"lat":e.latitude,"lng":e.longitude,"intensity":e.detection_count} for e in db.scalars(select(Event).where(Event.event_type.in_(["vehicle_density","traffic_congestion"]))).all()]

@router.post("/routes/score")
def route_score(payload: RouteScoreRequest, db: Session=Depends(get_db)):
    route=db.get(Route,payload.route_id)
    if not route: raise HTTPException(404,"Route not found")
    total,severity=score_route(payload)
    row=RouteScore(**payload.model_dump(),consequence_score=total,severity=severity); db.add(row); db.commit()
    return {"route_id":route.id,"route":route.name,"consequence_score":total,"severity":severity}

@router.get("/routes/compare")
def route_compare(db: Session=Depends(get_db)):
    rows=db.execute(select(Route,RouteScore).join(RouteScore,Route.id==RouteScore.route_id).order_by(RouteScore.consequence_score)).all()
    return [{"route_id":r.id,"name":r.name,"origin":r.origin,"destination":r.destination,"distance_km":r.distance_km,"score":s.consequence_score,"severity":s.severity,"traffic":s.traffic_score,"road":s.road_condition_score,"waterlogging":s.waterlogging_score,"hazard":s.hazard_score} for r,s in rows]

@router.get("/dashboard/{role}")
def dashboard(role: str, db: Session=Depends(get_db)):
    return {"role":role,"events":db.scalar(select(func.count(Event.id))) or 0,"incidents":db.scalar(select(func.count(Incident.id))) or 0,"detections":db.scalar(select(func.count(Detection.id))) or 0,"buses":db.scalar(select(func.count(Bus.id)).where(Bus.status=="active")) or 0}
