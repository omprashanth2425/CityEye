from app.config import settings

def score_route(values):
    weights = [settings.route_weight_traffic, settings.route_weight_road, settings.route_weight_water,
               settings.route_weight_hazard, settings.route_weight_distance]
    vals = [values.traffic_score, values.road_condition_score, values.waterlogging_score, values.hazard_score, values.distance_score]
    total = sum(w*v for w,v in zip(weights, vals)) / sum(weights)
    severity = "Low" if total < 35 else "Moderate" if total < 65 else "High"
    return round(total, 2), severity
