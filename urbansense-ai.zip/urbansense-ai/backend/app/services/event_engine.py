from datetime import timedelta
from math import radians, sin, cos, sqrt, atan2
from uuid import uuid4
from sqlalchemy import select
from app.models.entities import Event, EventDetection
from app.config import settings

def distance_m(lat1, lon1, lat2, lon2):
    R = 6371000
    p1, p2 = radians(lat1), radians(lat2)
    dp, dl = radians(lat2-lat1), radians(lon2-lon1)
    a = sin(dp/2)**2 + cos(p1)*cos(p2)*sin(dl/2)**2
    return 2*R*atan2(sqrt(a), sqrt(1-a))

def severity_for(event_type, confidence):
    if event_type in {"accident", "hit_and_run"} or confidence >= .9: return "High"
    if confidence >= .75: return "Moderate"
    return "Low"

def upsert_event(db, detection):
    low = detection.detected_at - timedelta(seconds=settings.event_match_window_s)
    candidates = db.scalars(select(Event).where(Event.event_type == detection.detection_type, Event.last_detected_at >= low)).all()
    event = next((e for e in candidates if distance_m(e.latitude,e.longitude,detection.latitude,detection.longitude) <= settings.event_match_radius_m), None)
    if event:
        event.last_detected_at = detection.detected_at
        event.detection_count += 1
        event.evidence_url = detection.evidence_url or event.evidence_url
    else:
        event = Event(event_id=f"EVT-{uuid4().hex[:8].upper()}", event_type=detection.detection_type,
                      latitude=detection.latitude, longitude=detection.longitude,
                      first_detected_at=detection.detected_at, last_detected_at=detection.detected_at,
                      severity=severity_for(detection.detection_type,detection.confidence), evidence_url=detection.evidence_url)
        db.add(event); db.flush()
    db.add(EventDetection(event_id=event.id, detection_id=detection.id, bus_id=detection.bus_id, detected_at=detection.detected_at))
    return event
