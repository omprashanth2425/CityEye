class DetectionEngine:
    """Replaceable interface for YOLO + OpenCV inference."""
    def detect(self, frame):
        raise NotImplementedError

class MockDetector(DetectionEngine):
    def detect(self, frame):
        return []

class YOLOOpenCVDetector(DetectionEngine):
    def __init__(self, model_path: str):
        self.model_path = model_path
        self.model = None
        try:
            from ultralytics import YOLO
            self.model = YOLO(model_path)
        except Exception:
            self.model = None

    def detect(self, frame):
        if self.model is None:
            return []
        results = self.model(frame, verbose=False)
        return [
            {"label": str(r.names[int(box.cls[0])]), "confidence": float(box.conf[0])}
            for r in results for box in r.boxes
        ]
