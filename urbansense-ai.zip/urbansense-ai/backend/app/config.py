from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "postgresql+psycopg://urbansense:urbansense@localhost:5432/urbansense"
    event_match_radius_m: float = 50.0
    event_match_window_s: int = 300
    route_weight_traffic: float = 0.30
    route_weight_road: float = 0.25
    route_weight_water: float = 0.20
    route_weight_hazard: float = 0.15
    route_weight_distance: float = 0.10
    cors_origins: str = "http://localhost:5173,http://localhost:4173"
    model_path: str = "models/urbansense.pt"
    model_enabled: bool = False
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
