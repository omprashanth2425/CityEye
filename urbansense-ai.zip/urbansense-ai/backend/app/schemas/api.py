from datetime import datetime
from pydantic import BaseModel, Field

class DetectionCreate(BaseModel):
    bus_id: int
    detection_type: str
    confidence: float = Field(ge=0, le=1)
    latitude: float
    longitude: float
    detected_at: datetime
    evidence_url: str | None = None
    frame_reference: str | None = None

class DetectionOut(DetectionCreate):
    id: int
    status: str
    model_config = {"from_attributes": True}

class EventOut(BaseModel):
    id: int
    event_id: str
    event_type: str
    latitude: float
    longitude: float
    first_detected_at: datetime
    last_detected_at: datetime
    detection_count: int
    severity: str
    status: str
    evidence_url: str | None
    model_config = {"from_attributes": True}

class IncidentCreate(BaseModel):
    incident_type: str
    latitude: float
    longitude: float
    detected_at: datetime
    evidence_url: str | None = None
    vehicle_detected: bool = False
    plate_number: str | None = None
    plate_confidence: float | None = None

class IncidentOut(IncidentCreate):
    id: int
    incident_id: str
    verification_status: str
    event_id: int | None
    model_config = {"from_attributes": True}

class RouteScoreRequest(BaseModel):
    route_id: int
    traffic_score: float = Field(ge=0, le=100)
    road_condition_score: float = Field(ge=0, le=100)
    waterlogging_score: float = Field(ge=0, le=100)
    hazard_score: float = Field(ge=0, le=100)
    distance_score: float = Field(ge=0, le=100)
