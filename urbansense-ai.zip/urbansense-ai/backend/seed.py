from datetime import datetime, timezone, timedelta
from app.database.db import Base, engine, SessionLocal
from app.models.entities import Bus, Event, Incident, Route, RouteScore
Base.metadata.create_all(bind=engine)
db=SessionLocal()
if not db.query(Bus).first():
    db.add_all([Bus(vehicle_number="AP21-B-101",fleet_id="KURNOOL-01",last_latitude=15.8281,last_longitude=78.0373,last_seen_at=datetime.now(timezone.utc)),Bus(vehicle_number="AP21-B-102",fleet_id="KURNOOL-01",last_latitude=15.8310,last_longitude=78.0410,last_seen_at=datetime.now(timezone.utc))])
    now=datetime.now(timezone.utc)
    db.add_all([
      Event(event_id="EVT-DEMO01",event_type="pothole",latitude=15.8281,longitude=78.0373,first_detected_at=now-timedelta(minutes=20),last_detected_at=now,detection_count=3,severity="High",status="open"),
      Event(event_id="EVT-DEMO02",event_type="waterlogging",latitude=15.8310,longitude=78.0410,first_detected_at=now-timedelta(minutes=10),last_detected_at=now,detection_count=2,severity="Moderate",status="open"),
      Event(event_id="EVT-DEMO03",event_type="traffic_congestion",latitude=15.8250,longitude=78.0350,first_detected_at=now-timedelta(minutes=5),last_detected_at=now,detection_count=5,severity="High",status="open"),
    ])
    db.add(Incident(incident_id="INC-DEMO01",incident_type="hit_and_run",verification_status="verified",vehicle_detected=True,plate_number="AP21AB1234",plate_confidence=.91,latitude=15.829,longitude=78.039,detected_at=now))
    r1=Route(name="Route A",origin="City Center",destination="Bus Terminal",distance_km=6.4); r2=Route(name="Route B",origin="City Center",destination="Bus Terminal",distance_km=7.1); db.add_all([r1,r2]); db.flush()
    db.add_all([RouteScore(route_id=r1.id,traffic_score=65,road_condition_score=70,waterlogging_score=20,hazard_score=55,distance_score=45,consequence_score=54.5,severity="Moderate"),RouteScore(route_id=r2.id,traffic_score=35,road_condition_score=25,waterlogging_score=10,hazard_score=20,distance_score=60,consequence_score=29.5,severity="Low")])
    db.commit()
db.close(); print("Seed complete")
