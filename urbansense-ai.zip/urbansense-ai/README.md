# UrbanSense AI

UrbanSense AI is an AI-powered urban intelligence platform that converts public transport buses into continuously operating mobile sensing units. This implementation follows the confirmed product specification extracted from the supplied Team OMNIX deck.

## Stack
- Backend: Python, FastAPI, PostgreSQL/PostGIS
- AI/CV interface: YOLO + OpenCV (replaceable detector; mock mode included)
- Frontend: React, Leaflet, OpenStreetMap
- Marketing website: React + Vite
- Infrastructure: Docker Compose for PostGIS

## Architecture
`Bus cameras + GPS -> Video/Location -> AI analysis -> Confidence check -> Event/Incident -> Unique Event Engine -> GIS/Traffic Heatmap/Incident DB -> Consequence Engine -> Route scoring -> Recommendation`

## Run locally
### 1. Database
```bash
docker compose up -d
```

### 2. Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env  # Windows
# cp .env.example .env # macOS/Linux
python seed.py
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs

### 3. Frontend
```bash
cd frontend
npm install
# copy .env.example to .env if needed
npm run dev
```
Open http://localhost:5173

### 4. Landing website
```bash
cd website
npm install
npm run dev -- --port 4173
```
Open http://localhost:4173

## Core API
- `POST /api/detections` — ingest a bus AI detection; confidence check and event correlation happen automatically.
- `GET /api/events` — consolidated events.
- `GET /api/map/events` — map-ready event data.
- `POST /api/incidents` — create an incident record with verification/ANPR fields.
- `GET /api/incidents` — incident records.
- `POST /api/routes/score` — score a route using the deck's five consequence inputs.
- `GET /api/routes/compare` — route comparison data.
- `GET /api/dashboard/{role}` — stakeholder dashboard summary.

## Explicit implementation assumptions
The supplied deck does not specify these values, so they are configurable in `.env`:
1. Event correlation radius: default 50 m.
2. Event correlation time window: default 300 s.
3. Route weights: Traffic 30%, Road Condition 25%, Waterlogging 20%, Hazards 15%, Distance 10%.
4. Route severity: score <35 Low, 35–<65 Moderate, >=65 High.
5. Event severity: confidence/type based initial rule; replace with the production policy/model later.
6. YOLO weights/training dataset and ANPR model are not supplied by the deck. The code therefore exposes a replaceable detector interface and a runnable mock mode.
7. Authentication is not presented as a full identity provider because the deck only specifies secure access/controlled data. The role selector in the demo is a stakeholder-view switch, not production authorization.
8. No external routing provider is required for the demo; seeded candidate routes demonstrate the consequence engine. A production deployment can plug in a GIS routing service.

## Production hardening
Add real identity/authentication, HTTPS, signed evidence URLs, object storage, PostGIS spatial indexes, asynchronous video inference, model monitoring, audit logs, rate limiting, privacy retention policies, and a real routing/ANPR provider before operational deployment.

## Deck links
The deck supplied a prototype URL and a demonstration video. They are references from the source presentation, not required runtime dependencies.
